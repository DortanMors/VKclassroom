self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "f8cf90515eade59e3fdfc56031778324",
    "url": "/index.html"
  },
  {
    "revision": "924e75cbf716f0ef8945",
    "url": "/static/css/2.86df01db.chunk.css"
  },
  {
    "revision": "fcb63f443f059a990ccb",
    "url": "/static/css/main.8a65da0f.chunk.css"
  },
  {
    "revision": "924e75cbf716f0ef8945",
    "url": "/static/js/2.e514838c.chunk.js"
  },
  {
    "revision": "8fb5603b7e46dc3876455cb1e20af4fe",
    "url": "/static/js/2.e514838c.chunk.js.LICENSE.txt"
  },
  {
    "revision": "fd17e91f7462c79b44d9",
    "url": "/static/js/3.42b7a6ac.chunk.js"
  },
  {
    "revision": "d7443f9307dcf29caba326ef49b2f7f6",
    "url": "/static/js/3.42b7a6ac.chunk.js.LICENSE.txt"
  },
  {
    "revision": "36d6a77dcabcb178e2f4",
    "url": "/static/js/4.89466b52.chunk.js"
  },
  {
    "revision": "fcb63f443f059a990ccb",
    "url": "/static/js/main.87332e52.chunk.js"
  },
  {
    "revision": "995c46dae852ffe38b30",
    "url": "/static/js/runtime-main.8905197c.js"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "/static/media/persik.4e1ec840.png"
  }
]);