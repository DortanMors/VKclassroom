self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "231cd2fdb9e3bad0b1ea439ff4495730",
    "url": "/index.html"
  },
  {
    "revision": "1e29097c65d7192b5da1",
    "url": "/static/css/2.86df01db.chunk.css"
  },
  {
    "revision": "361d1453d9dce7e3879a",
    "url": "/static/css/main.7e0f6e90.chunk.css"
  },
  {
    "revision": "1e29097c65d7192b5da1",
    "url": "/static/js/2.34f09b22.chunk.js"
  },
  {
    "revision": "8fb5603b7e46dc3876455cb1e20af4fe",
    "url": "/static/js/2.34f09b22.chunk.js.LICENSE.txt"
  },
  {
    "revision": "361d1453d9dce7e3879a",
    "url": "/static/js/main.952d402d.chunk.js"
  },
  {
    "revision": "ecdce4bdea8a57713a22",
    "url": "/static/js/runtime-main.16ffc480.js"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "/static/media/persik.4e1ec840.png"
  }
]);